module.exports = {
    content: '*.{html,jsx,js}'
}