const enableDarkThemeCheckbox = document.querySelector('#enable-dark-theme-checkbox')
const hueRotationRangeInput = document.querySelector('#hue-rotation-range-input')
const contrastRangeInput = document.querySelector('#contrast-range-input')
const giveJobListingCardsBackgroundCheckbox = document.querySelector('#give-job-listing-cards-background-checkbox')

document.addEventListener('DOMContentLoaded', () => {
    enableDarkThemeCheckbox.checked = localStorage.theme === 'dark'

    hueRotationRangeInput.value = Number(localStorage.hueRotation)
    document.querySelector('#hue-rotation-label-text-element').innerText = `Hue rotation (${Number(localStorage.hueRotation) > 0 ? '+' : ''}${Number(localStorage.hueRotation)}°)`

    contrastRangeInput.value = Number(localStorage.contrast)
    document.querySelector('#contrast-label-text-element').innerText = `Contrast (${Number(localStorage.contrast) - 1 > 0 ? '+' : ''}${Number((Number(localStorage.contrast) - 1).toFixed(2))})`

    document.querySelector('#theme-options-wrapper').dispatchEvent(new InputEvent('input'))
})

document.querySelector('#theme-options-wrapper').addEventListener('input', ev => {
    localStorage.theme = enableDarkThemeCheckbox.checked ? 'dark' : 'light'
    localStorage.hueRotation = hueRotationRangeInput.valueAsNumber
    localStorage.contrast = contrastRangeInput.valueAsNumber

    document.querySelector('html').style.filter = `
        ${enableDarkThemeCheckbox.checked ? `invert(1)` : ''}
        hue-rotate(${hueRotationRangeInput.valueAsNumber + (enableDarkThemeCheckbox.checked ? 180 : 0)}deg)
        contrast(${contrastRangeInput.value})
    `

    const jobListingCardBackgroundMode = document.querySelector('input[type="radio"][name="job-listing-cards-background"]:checked').value

    document.querySelectorAll('[data-job-listing]').forEach(jobListingCard => {
        jobListingCard.classList.remove(
            [...jobListingCard.classList].find(className => className.startsWith('bg-'))
        )

        jobListingCard.classList.add(
            jobListingCardBackgroundMode === 'Subtle'
                ? 'bg-[#f9f9f9]'
                : jobListingCardBackgroundMode === 'Accentuated'
                    ? 'bg-[#e8e8e8]'
                    : 'bg-white'
        )
    })
})

// Show or hide job listing cards background strength options based on whether job listings "page" is open or not.

getJobListingsButton.addEventListener('click', () => {
    document.querySelector('#job-listing-cards-background-strength-fieldset').classList.replace('hidden', 'flex')
})

createAccountButton.addEventListener('click', () => {
    document.querySelector('#job-listing-cards-background-strength-fieldset').classList.replace('flex', 'hidden')
})


getMessagesButton.addEventListener('click', () => {
    document.querySelector('#job-listing-cards-background-strength-fieldset').classList.replace('flex', 'hidden')
})


logInOutButton.addEventListener('click', () => {
    document.querySelector('#job-listing-cards-background-strength-fieldset').classList.replace('flex', 'hidden')
})
