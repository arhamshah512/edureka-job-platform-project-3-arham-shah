const getJobListingsButton = document.querySelector('#getJobListingsButton')
const createAccountButton = document.querySelector('#createAccountButton')
const logInOutButton = document.querySelector('#logInOutButton')
const getMessagesButton = document.querySelector('#getMessagesButton')

const jobListingsWrapper = document.querySelector('#job-listings-wrapper')

const html = String.raw

function getIsLoggedIn() {
    return localStorage.currentUser != 'null'
}

/**
 * Uppercases the first character of the given string
 */
function uppercaseFirst(text) {
    return text[0].toUpperCase() + text.slice(1)
}

/**
 * @param {string} ref 
 * @returns {HTMLElement}
 */
function getElementByRef(ref) {
    return document.querySelector(`[data-ref="${ref}"]`)
}

function popUp(text) {
    const $dialog = $('<dialog class="flex flex-col px-6 py-4 text-lg border-none rounded-md backdrop:backdrop-blur-md" />')

    $dialog.on('keydown', ev => {
        if (ev.key !== 'Escape') return
        $dialog.remove()
    })

    $dialog.append(`
        <button type="button" class="ml-auto" @click="$event.target.closest('dialog').remove()" title="Close alert">
            <i class="bi bi-x-lg text-rose-800" aria-hidden="true"></i>
        </button>

        <p>${text}</p>
    `)

    $(document.body).append($dialog)

    $dialog[0].showModal()
}

function getUniqueRef() {
    return '_' + crypto.randomUUID().replaceAll('-', '')
}

function getCurrentUserId() {
    return JSON.parse(localStorage.currentUser)._id
}

$('[data-page]').hide()

$('#getJobListingsButton').on('click', () => {
    $('[data-page]').hide()
    $('#job-listings-page').show()
})

$('#createAccountButton').on('click', () => {
    $('[data-page]').hide()
    $('#account-creation-form').show()
})

$('#getMessagesButton').on('click', () => {
    $('[data-page]').hide()
    $('#messages-page').show()
})

const accountCreationRevealHidePasscodeButton = document.querySelector('#account-creation-reveal-hide-passcode-button')

accountCreationRevealHidePasscodeButton.addEventListener('click', ev => {
    if (ev.target.innerText.trim() === 'Reveal passcode') {
        document.querySelector('#account-creation-passcode-input').type = 'text'

        ev.target.innerHTML = `
            <i class="bi bi-eye-slash" aria-hidden="true"></i>
            Hide passcode
        `
    } else if ((ev.target.innerText.trim() === 'Hide passcode')) {
        document.querySelector('#account-creation-passcode-input').type = 'password'

        ev.target.innerHTML = `
            <i class="bi bi-eye" aria-hidden="true"></i>
            Reveal passcode
        `
    }
})

$('#logInOutButton').on('click', ev => {
    if (ev.target.innerText == 'Login') {
        $('[data-page]').hide()
        $('#login-page').show()
    } else {
        if (!confirm('Are you sure you want to log out?')) return

        $('[data-page]').hide()
        ev.target.innerText = 'Login'
        localStorage.currentUser = null
    }
})

const loginRevealHidePasscodeButton = document.querySelector('#login-reveal-hide-passcode-button')

loginRevealHidePasscodeButton.addEventListener('click', ev => {
    if (ev.target.innerText.trim() === 'Reveal passcode') {
        document.querySelector('#login-passcode-input').type = 'text'

        ev.target.innerHTML = `
            <i class="bi bi-eye-slash" aria-hidden="true"></i>
            Hide passcode
        `
    } else if ((ev.target.innerText.trim() === 'Hide passcode')) {
        document.querySelector('#login-passcode-input').type = 'password'

        ev.target.innerHTML = `
            <i class="bi bi-eye" aria-hidden="true"></i>
            Reveal passcode
        `
    }
})

document.querySelector('[data-login-form]').addEventListener('submit', async ev => {
    ev.preventDefault()

    const response =
        await fetch('http://localhost:3000/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: ev.target.querySelector('[x-model="username"]').value,
                hashedPasscode: sha256(ev.target.querySelector('[x-model="plainPasscode"]').value + '@lsteδ satiθn-syncr3ti')
            })
        })
    ;

    response.text().then(res => {
        if (res === 'Username does not exist.') {
            popUp('Username does not exist.')
        } else if (res === 'Incorrect passcode.') {
            popUp('Incorrect passcode.')
        } else {
            document.querySelector('#login-passcode-input').type = 'password'

            document.querySelector('#login-reveal-hide-passcode-button').innerHTML = `
                <i class="bi bi-eye" aria-hidden="true"></i>
                Reveal passcode
            `

            localStorage.currentUser = res
            logInOutButton.innerText = 'Logout'
            popUp('Login successful ✅')
        }
    })
})

$('#logInOutButton').text(localStorage.getItem('currentUser') == 'null' ? 'Login' : 'Logout')

;(function updateByLoginStatus() {
    requestAnimationFrame(updateByLoginStatus)

    document.querySelector('#filter-job-listings-fieldset-for-job-seekers').hidden = !(localStorage.getItem('currentUser') != 'null' && JSON.parse(localStorage.currentUser).role === 'Job Seeker')
    document.querySelector('#filter-job-listings-fieldset-for-employers').hidden = !(localStorage.getItem('currentUser') != 'null' && JSON.parse(localStorage.currentUser).role === 'Employer')

    $('#logInOutButton').text(localStorage.getItem('currentUser') == 'null' ? 'Login' : 'Logout')

    $('#user-login-status')[0].innerHTML = (
        localStorage.getItem('currentUser') == 'null'
            ? `
                <div class="p-8 bg-neutral-100 space-y-2">
                    <p class="text-lg mb-4">You are not logged in.</p>
                    <p>Create an account if you do not have one. Login to view job listings and create jobs as an employer, apply for jobs as a job seeker or send and receive messages.</p>
                </div>
            `
            : `
                <div class="p-8 bg-neutral-100 space-y-2">
                    <p class="text-lg mb-4">You are logged in (${JSON.parse(localStorage.currentUser).role}).</p>

                    <div>
                        <button type="button" class="flex gap-2" x-on:click="
                            navigator.clipboard.writeText(\`${JSON.parse(localStorage.currentUser).name}\`)
                        ">
                            <i class="bi bi-copy" aria-hidden="true"></i>
                            Copy name
                        </button>

                        <p>${JSON.parse(localStorage.currentUser).name}</p>
                    </div>

                    <div>
                        <button type="button" class="flex gap-2" x-on:click="
                            navigator.clipboard.writeText(\`${JSON.parse(localStorage.currentUser).username}\`)
                        ">
                            <i class="bi bi-copy" aria-hidden="true"></i>
                            Copy username
                        </button>

                        <p class="text-gray-700 font-mono">${JSON.parse(localStorage.currentUser).username}</p>
                    </div>
                </div>
            `
    )
})()

function isUsernameValid(username) {
    return (
        username.trim() !== '' &&
        username.trim().length >= 4 &&
        username.trim().length <= 40 &&
        !username.startsWith('.') &&
        /[0-9]/.test(username) &&
        !/[^a-zA-Z0-9\._\-]/.test(username)
    )
}

function isPasscodeValid(passcode) {
    return (
        passcode.trim().length >= 8 &&
        /[0-9]/.test(passcode) &&
        /[a-z]/.test(passcode) &&
        /[A-Z]/.test(passcode) &&
        /[!@#\$%\^&\*\(\)\[\]\{\}_\+:;'",\.\/\|`~=\-\?><\\]/.test(passcode)
    )
}

// For employers only. "Create job listing" button is employers-only
if (localStorage.currentUser != 'null') {
    document.querySelector('#create-job-listing-form-wrapper-dialog').innerHTML = html`
        <form x-data="{
            id: '',
            title: '',
            description: '',
            duration: '',
            requirements: [],
            location: '',
            pay: '',
            employerId: '${getCurrentUserId()}'
        }" id="create-job-listing-form" class="p-8 flex flex-col md:w-1/2 lg:w-full" @submit.prevent="
            const res = await fetch('http://localhost:3000/api/create-job-listing', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id,
                    title,
                    description,
                    duration,
                    requirements,
                    location,
                    pay,
                    employerId
                })
            })

            console.log('Create job listing form submit', await res.json())
        ">
            <button type="button" class="ml-auto" @click="$event.target.closest('dialog').remove()" title="Close alert">
                <i class="bi bi-x-lg text-rose-800" aria-hidden="true"></i>
            </button>

            <h2 class="text-3xl font-bold">Create job listing</h2>

            <label class='grid gap-2 mt-4 font-medium'>
                Title
                <input class='rounded-md' type="text" x-model="title" required />
            </label>

            <label class='grid gap-2 mt-4 font-medium'>
                Description
                <textarea class='rounded-md' type="text" x-model="description" required></textarea>
            </label>

            <label class='grid gap-2 mt-4 font-medium'>
                Duration of work
                <input class='rounded-md' type="text" x-model="duration" required>
            </label>

            <label class='grid gap-2 mt-4 font-medium'>
                Requirements (each on new line)
                <textarea class='rounded-md' type="text" @input="requirements = $event.target.value.split('\n')" required></textarea>
            </label>

            <label class='grid gap-2 mt-4 font-medium'>
                Location
                <textarea class='rounded-md' type="text" x-model="location" required></textarea>
            </label>

            <label class='grid gap-2 mt-4 font-medium'>
                Pay
                <input class='rounded-md' type="text" x-model="pay" required>
            </label>

            <button type='submit' class='mt-8 px-6 py-3 w-max leading-none bg-brand rounded-full text-white'>Create job listing</button>
        </form>
    `
}

/**
 * @typedef {{ _id: string, title: string, description: string, duration: string, requirements: string[], location: string, pay: string, employerId: string }} JobListingType
 */

getJobListingsButton.addEventListener('click', () => {
    fetch('http://localhost:3000/api/get-job-listings')
        .then(response => response.json())
        .then(async (/** @type {JobListingType[]} */ jobListings) => {
            jobListingsWrapper.innerHTML = ''

            jobListings.forEach(async (jobListing, index) => {
                const jobSeekers = await (await fetch('http://localhost:3000/api/get-job-seekers')).json()
                const employers = await (await fetch('http://localhost:3000/api/get-employers')).json()

                const applications = await (await fetch('http://localhost:3000/api/get-applications')).json()

                const requirementsWrapperRef = getUniqueRef()
                const jobListingButtonWrapperRef = getUniqueRef()

                // LOGGED IN
                if (getIsLoggedIn()) {
                    // FOR Job Seekers
                    if (JSON.parse(localStorage.currentUser).role === 'Job Seeker') {
                        const hasJobSeekerAppliedForThisJob = jobSeekers.find(jobSeeker => jobSeeker._id === getCurrentUserId()).jobsAppliedFor.includes(jobListing._id)

                        const currentApplication = applications.find(application => application.jobListing === jobListing._id && application.jobSeeker == getCurrentUserId())
                        const currentApplicationStatusRef = getUniqueRef()

                        // Button if not applied: "Apply"
                        const applyButtonRef = getUniqueRef()

                        // Buttons if applied: "View application" and "Unapply"
                        const viewApplicationButtonRef = getUniqueRef()
                        const unapplyButtonRef = getUniqueRef()

                        const employerNameElementRef = getUniqueRef()

                        jobListingsWrapper.innerHTML += html`
                            <div class="w-[18rem] px-5 py-6 border border-gray-300 rounded-xl space-y-4" data-id="${jobListing._id}" data-employer-id="${jobListing.employerId}" data-job-listing>
                                <div data-job-listing-button-wrapper data-ref="${jobListingButtonWrapperRef}"></div>
                                <h3 class="font-medium text-2xl">${jobListing.title}</h3>
                                <p class="-my-4" data-ref="${currentApplicationStatusRef}" data-application-status></p>
                                <p class="underline cursor-pointer" data-ref="${employerNameElementRef}" data-employer-name>
                                    ${employers.find(employer => employer._id === jobListing.employerId).name}<p>
                                    <span class="font-mono">${employers.find(employer => employer._id === jobListing.employerId).username}</span>
                                </p>
                                <p class="text-sm">${jobListing.description}</p>
                                <p class="text-brand">${jobListing.duration}</p>
                                <div class="flex flex-wrap gap-2 text-sm *:leading-none *:px-3 *:py-2 *:rounded-full *:bg-gray-100 *:w-max" data-ref="${requirementsWrapperRef}">
                                    <!-- Filled by JS -->
                                </div>
                                <div class="flex items-center gap-2" title="Location">
                                    <i class="bi bi-geo-alt" aria-hidden="true"></i>
                                    <p>${jobListing.location}</p>
                                </div>
                                <p class="text-2xl">${jobListing.pay}</p>
                            </div>
                        `

                        setTimeout(() => {
                            getElementByRef(employerNameElementRef).addEventListener('click', ev => {
                                if (!confirm("Search this employer's name?")) return

                                document.querySelector('#search-job-listings-input').value = ev.target.innerText
                                document.querySelector('#search-job-listings-button').click()
                            })

                            jobListing.requirements.forEach(requirement => {
                                getElementByRef(requirementsWrapperRef).innerHTML += `
                                    <p class="whitespace-nowrap">${requirement}</p>
                                `
                            })

                            // START job listing buttons

                            const jobListingButtonWrapper = getElementByRef(jobListingButtonWrapperRef)

                            if (currentApplication == null) {
                                jobListingButtonWrapper.innerHTML = html`
                                    <button type='button' class='px-6 py-3 w-max leading-none bg-[#dbe3f0] rounded-full text-black' data-ref="${applyButtonRef}" data-apply-button>Apply</button>
                                `
                            } else {
                                jobListingButtonWrapper.innerHTML = html`
                                    <button type='button' class='px-6 py-3 w-max leading-none bg-[#dbe3f0] rounded-full text-black' data-ref="${viewApplicationButtonRef}" data-view-application-button>View Application</button>

                                    <!-- Show "Unapply" button if the application is pending or accepted. It doesn't make sense to show it for a rejected application, as the process is already concluded. -->
                                    ${(currentApplication?.status === 'accepted' || currentApplication?.status === 'pending')
                                        ? html`<button type='button' class='mt-2.5 px-6 py-3 w-max leading-none bg-[#f0dbdb] rounded-full text-black' data-ref="${unapplyButtonRef}" data-unapply-button>Unapply</button>`
                                        : ''
                                    }
                                `
                            }

                            const currentApplicationStatusElement = getElementByRef(currentApplicationStatusRef)

                            if (currentApplication?.status === 'rejected') {
                                currentApplicationStatusElement.className = 'bg-rose-100 text-rose-800 !-mt-0.5 px-2.5 py-1 rounded-full w-max flex items-center gap-2'

                                currentApplicationStatusElement.innerHTML = `
                                    <i class="bi bi-x-circle" aria-hidden="true"></i>
                                    Rejected
                                `
                            } else if (currentApplication?.status === 'accepted') {
                                currentApplicationStatusElement.className = 'bg-emerald-100 text-emerald-900 !-mt-0.5 px-2.5 py-1 rounded-full w-max flex items-center gap-2'

                                currentApplicationStatusElement.innerHTML = `
                                    <i class="bi bi-check-circle" aria-hidden="true"></i>
                                    Accepted
                                `
                            } else if (currentApplication?.status === 'pending') {
                                currentApplicationStatusElement.className = 'bg-amber-100 text-amber-900 !-mt-0.5 px-2.5 py-1 rounded-full w-max flex items-center gap-2'

                                currentApplicationStatusElement.innerHTML = `
                                    <i class="bi bi-dash-circle" aria-hidden="true"></i>
                                    Pending
                                `

                                currentApplicationStatusElement.className = 'bg-amber-100 text-amber-900 !-mt-0.5 px-2.5 py-1 rounded-full w-max flex items-center gap-2'
                            }

                            document.querySelector(`[data-id="${jobListing._id}"]`).addEventListener('click', async ev => {
                                if (ev.target.matches('[data-apply-button')) {
                                    const sendApplicationFormRef = getUniqueRef()

                                    document.querySelector('#send-application-form-wrapper-dialog').innerHTML = html`
                                        <button type="button" @click="$event.target.closest('dialog').close()" title="Close alert" class="flex items-top gap-2 text-rose-800">
                                            <i class="bi bi-x-lg" aria-hidden="true"></i>
                                            Close
                                        </button>

                                        <form data-ref="${sendApplicationFormRef}">
                                            <label class='grid gap-2 mt-4 font-medium'>
                                                <p class="font-medium">Text to share with the employer</p>
                                                <p>Bio, personal information, education, skills, projects, links such as to GitHub / Linkedin / X (Twitter),    qualities and values are examples of things to share.</p>
                                                <textarea data-application-text class='rounded-md max-w-full' required></textarea>
                                            </label>

                                            <button type="submit" class="my-4 leading-none px-4 py-2 rounded-full bg-brand text-white">Send application</button>
                                        </form>
                                    `

                                    getElementByRef(sendApplicationFormRef).addEventListener('submit', async ev => {
                                        ev.preventDefault()

                                        if (!ev.target.reportValidity()) {
                                            return
                                        } else {
                                            ev.target.closest('dialog').close()
                                        }

                                        await fetch('http://localhost:3000/api/send-application', {
                                            method: 'POST',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                jobListing: jobListing._id,
                                                jobSeeker: JSON.parse(localStorage.currentUser),
                                                text: ev.target.querySelector('textarea[data-application-text]').value,
                                                status: 'pending'
                                            })
                                        })

                                        getJobListingsButton.click()
                                    })

                                    document.querySelector("#send-application-form-wrapper-dialog").showModal()
                                }

                                if (ev.target.matches('[data-unapply-button]')) {
                                    if (!confirm('Are you sure you want to unapply? This will remove the application and cannot be undone.')) {
                                        return
                                    }

                                    jobListingButtonWrapper.innerHTML = html`
                                        <button type='button' class='px-6 py-3 w-max leading-none bg-[#dbe3f0] rounded-full text-black' data-ref="${applyButtonRef}" data-apply-button>Apply</button>
                                    `

                                    if (getElementByRef(currentApplicationStatusRef) != null){
                                        getElementByRef(currentApplicationStatusRef).outerHTML = ''
                                    }

                                    await fetch(`http:localhost:3000/api/delete-application/`, {
                                        method: 'DELETE',
                                        headers: {
                                            'Content-Type': 'application/json'
                                        },
                                        body: JSON.stringify({
                                            applicationId: currentApplication._id
                                        })
                                    })

                                    
                                    getJobListingsButton.click()
                                }

                                if (ev.target.matches('[data-view-application-button]')) {
                                    popUp(currentApplication.text)
                                }
                            })
                        }, 100)
                    }

                    // FOR Employers
                    else {
                        const manageApplicationsButtonRef = getUniqueRef()
                        const jobSeekers = await (await fetch('http://localhost:3000/api/get-job-seekers')).json()
                        const applicationsWrapperRef = getUniqueRef()

                        const employerNameElementRef = getUniqueRef()

                        jobListingsWrapper.innerHTML += html`
                            <div class="w-[18rem] px-5 py-6 border border-gray-300 rounded-xl space-y-4" data-id="${jobListing._id}" data-employer-id="${jobListing.employerId}" data-job-listing>
                                <div data-job-listing-button-wrapper data-ref="${jobListingButtonWrapperRef}"></div>
                                <h3 class="font-medium text-2xl">${jobListing.title}</h3>
                                <p class="underline cursor-pointer" data-ref="${employerNameElementRef}" data-employer-name>
                                    ${employers.find(employer => employer._id === jobListing.employerId).name}<p>
                                    <span class="font-mono">
                                </p>
                                <p class="text-sm">${jobListing.description}</p>
                                <p class="text-brand">${jobListing.duration}</p>
                                <div class="flex flex-wrap gap-2 text-sm *:leading-none *:px-3 *:py-2 *:rounded-full *:bg-gray-100 *:w-max" data-ref="${requirementsWrapperRef}">
                                    <!-- Filled by JS -->
                                </div>
                                <div class="flex items-center gap-2" title="Location">
                                    <i class="bi bi-geo-alt" aria-hidden="true"></i>
                                    <p>${jobListing.location}</p>
                                </div>
                                <p class="text-2xl">${jobListing.pay}</p>
                            </div>
                        `

                        setTimeout(() => {
                            getElementByRef(employerNameElementRef).addEventListener('click', ev => {
                                if (!confirm("Search this employer's name?")) return

                                document.querySelector('#search-job-listings-input').value = ev.target.innerText
                                document.querySelector('#search-job-listings-button').click()
                            })
                        }, 100)

                        if (jobListing.employerId !== getCurrentUserId()) {
                            getElementByRef(jobListingButtonWrapperRef).hidden = true
                            // Since it is not the current employer's own job listing,
                            // hide the job listing buttons wrapper as it has "Manage Applications" button.
                        }

                        getElementByRef(jobListingButtonWrapperRef).innerHTML = `
                            <button type='button' class='px-6 py-3 w-max leading-none bg-[#dbe3f0] rounded-full text-black' data-ref="${manageApplicationsButtonRef}" data-manage-applications-button>Manage Applications</button>
                        `

                        setTimeout(() => {
                            getElementByRef(manageApplicationsButtonRef).addEventListener('click', async ev => {
                                const applications = await (await fetch('http://localhost:3000/api/get-applications')).json()
                                const applicationsForCurrentJobListing = applications.filter(application => application.jobListing === ev.target.closest('[data-job-listing]').dataset.id)

                                if (applicationsForCurrentJobListing.length === 0) {
                                    popUp('No applications received')
                                    return
                                }

                                const $dialog = $('<dialog class="flex flex-col px-6 py-4 text-lg border-none rounded-md backdrop:backdrop-blur-md" />')

                                $dialog.append(html`
                                    <!-- Filtering -->

                                    <button type="button" class="ml-auto" @click="$event.target.closest('dialog').remove()" title="Close alert">
                                        <i class="bi bi-x-lg text-rose-800" aria-hidden="true"></i>
                                    </button>

                                    <div data-ref="${applicationsWrapperRef}" data-applications-wrapper></div>
                                `)

                                $(document.body).append($dialog)
                                $dialog[0].showModal()

                                $(window).on('keydown', ev => {
                                    if (ev.key !== 'Escape') return
                                    $dialog.remove()
                                })

                                applicationsForCurrentJobListing.forEach(application => {
                                    /* <div>
                                            <div class="mt-4">
                                                <p>${jobSeekers.find(jobSeeker => application.jobSeeker === jobSeeker._id).name}</p>
                                                <p>${jobSeekers.find(jobSeeker => application.jobSeeker === jobSeeker._id).username}</p>
                                    
                                                <div class="mt-2">
                                                    <button type="button" class="font-medium leading-none rounded-full px-2.5 py-1 mr-2 border border-gray-300">View application</button>
                                    
                                                    <div>
                                                        <button type="button" class="text-emerald-700">Accept</button>
                                                        <button type="button" class="text-rose-600">Reject</button>
                                                    </div>
                                                </div>
                                            </div>
                                    
                                            <hr class="mt-4">
                                    </div>

                                    jQuery code for above (structure) is below */

                                    const $applicationWrapper = $(`<div>`)
                                    const $infoAndActionsWrapper = $('<div class="mt-4">')

                                    $(getElementByRef(applicationsWrapperRef)).append($applicationWrapper)
                                    
                                    $applicationWrapper.append($infoAndActionsWrapper)
                                    
                                    $infoAndActionsWrapper.append($(`<p>${jobSeekers.find(jobSeeker => application.jobSeeker === jobSeeker._id).name}</p>`))
                                    $infoAndActionsWrapper.append($(`<p>${jobSeekers.find(jobSeeker => application.jobSeeker === jobSeeker._id).username}</p>`))
                                    
                                    const $applicationWrapperButtonsWrapper = $(`<div class="mt-2">`)
                                    $infoAndActionsWrapper.append($applicationWrapperButtonsWrapper)
                                    
                                    const $viewApplicationButton = $(`<button type="button" class="font-medium leading-none rounded-full px-2.5 py-1 mr-2 border border-gray-300">View application</button>`)
                                    const $sendMessageButton = $(`<button type="button" class="font-medium leading-none rounded-full px-2.5 py-1 mr-2 border border-gray-300">Send message</button>`)

                                    $applicationWrapperButtonsWrapper.append($viewApplicationButton)
                                    $applicationWrapperButtonsWrapper.append($sendMessageButton)
                                    
                                    const $acceptAndRejectButtonsWrapper = $('<div class="flex gap-2">')
                                    
                                    const $acceptButton = $(`<button type="button" class="text-emerald-700">Accept</button>`)
                                    const $rejectButton = $(`<button type="button" class="text-rose-600">Reject</button>`)
                                    
                                    $acceptAndRejectButtonsWrapper.append($acceptButton, $rejectButton)

                                    $applicationWrapper.append('<hr class="mt-4">')

                                    const codeIfAccepted = `
                                        <p class="mt-4">
                                            <i class="bi bi-check-circle" aria-hidden="true"></i>
                                            Accepted
                                        </p>
                                    `
                                    
                                    const codeIfRejected = `
                                        <p class="mt-4">
                                            <i class="bi bi-x-circle" aria-hidden="true"></i>
                                            Rejected
                                        </p>
                                    `
                                    
                                    if (application.status === 'accepted') {
                                        $acceptAndRejectButtonsWrapper.html(codeIfAccepted)
                                    } else if (application.status === 'rejected') {
                                        $acceptAndRejectButtonsWrapper.html(codeIfRejected)
                                    }
                                    
                                    $acceptButton.on('click', async () => {
                                        $acceptAndRejectButtonsWrapper.html(codeIfAccepted)
                                    
                                        await fetch('http://localhost:3000/api/update-application-status', {
                                            method: 'PUT',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                applicationId: application._id, 
                                                status: 'accepted'
                                            })
                                        })
                                    })
                                    
                                    $rejectButton.on('click', async () => {
                                        $acceptAndRejectButtonsWrapper.html(codeIfRejected)
                                    
                                        await fetch('http://localhost:3000/api/update-application-status', {
                                            method: 'PUT',
                                            headers: {
                                                'Content-Type': 'application/json'
                                            },
                                            body: JSON.stringify({
                                                applicationId: application._id, 
                                                status: 'rejected'
                                            })
                                        })
                                    })
                                    
                                    $applicationWrapperButtonsWrapper.append($acceptAndRejectButtonsWrapper)
                                    
                                    $viewApplicationButton.on('click', () => {
                                        popUp(application.text)
                                    })

                                    $sendMessageButton.on('click', async () => {
                                        const $dialog = $('<dialog class="px-6 py-4 flex flex-col">')
                                        $(document.body).append($dialog)

                                        $dialog.append($(`
                                            <button type="button" class="ml-auto" @click="$event.target.closest('dialog').remove()" title="Close alert">
                                                <i class="bi bi-x-lg text-rose-800" aria-hidden="true"></i>
                                            </button>
                                        `))

                                        const $form = $(`
                                            <form>
                                                <label class="flex flex-col gap-2">
                                                    Message to applicant
                                                    <textarea class="rounded resize"></textarea>
                                                </label>

                                                <button type="submit" class="mt-4 bg-brand text-white rounded-full px-8 py-2">Send message</button>
                                            </form>
                                        `)

                                        $dialog.append($form)

                                        $dialog[0].showModal()

                                        $form.on('submit', async ev => {
                                            ev.preventDefault()

                                            await fetch('http://localhost:3000/api/send-message', {
                                                method: 'POST',
                                                headers: {
                                                    'Content-Type': 'application/json'
                                                },
                                                body: JSON.stringify({
                                                    senderId: getCurrentUserId(),
                                                    receiverId: jobSeekers.find(jobSeeker => jobSeeker.applicationsMade.includes(application._id))._id,
                                                    text: ev.target.querySelector('textarea').value,
                                                    isRead: false
                                                })
                                            })

                                            
                                            console.log({
                                                senderId: getCurrentUserId(),
                                                receiverId: jobSeekers.find(jobSeeker => jobSeeker.applicationsMade.includes(application._id)),
                                                text: ev.target.querySelector('textarea').value,
                                                isRead: false
                                            })
                                        })
                                    })
                                })
                            })
                        }, 100)
                    }
                }

                // NOT LOGGED IN
                else {
                    const employerNameElementRef = getUniqueRef()

                    jobListingsWrapper.innerHTML += html`
                        <div class="w-[18rem] px-5 py-6 border border-gray-300 rounded-xl space-y-4" data-id="${jobListing._id}" data-employer-id="${jobListing.employerId}" data-job-listing>
                            <h3 class="font-medium text-2xl">${jobListing.title}</h3>
                            <p class="underline cursor-pointer" data-ref="${employerNameElementRef}" data-employer-name>${employers.find(employer => employer._id === jobListing.employerId).name}<br></p>
                            <p class="font-mono">${employers.find(employer => employer._id === jobListing.employerId).username}</p>
                            <p class="text-sm">${jobListing.description}</p>
                            <p class="text-brand">${jobListing.duration}</p>
                            <div class="flex flex-wrap gap-2 text-sm *:leading-none *:px-3 *:py-2 *:rounded-full *:bg-gray-100 *:w-max" data-ref="${requirementsWrapperRef}">
                                <!-- Filled by JS -->
                            </div>
                            <div class="flex items-center gap-2" title="Location">
                                <i class="bi bi-geo-alt" aria-hidden="true"></i>
                                <p>${jobListing.location}</p>
                            </div>
                            <p class="text-2xl">${jobListing.pay}</p>
                        </div>
                    `

                    setTimeout(() => {
                        getElementByRef(employerNameElementRef).addEventListener('click', ev => {
                            if (!confirm("Search this employer's name?")) return

                            document.querySelector('#search-job-listings-input').value = ev.target.innerText
                            document.querySelector('#search-job-listings-button').click()
                        })
                    }, 100)
                }
            })
        })
    // END Fetch Get Job Listings
})

getMessagesButton.addEventListener('click', async () => {
    if (localStorage.currentUser == 'null') {
        $('#messages-wrapper').html(`
            <p class="mt-2" role="note">Please log in send or receive messages.</p>
        `)

        return
    }

    fetch('http://localhost:3000/api/get-messages')
        .then(response => response.json())
        .then(messages => {
            $('#messages-wrapper').text('')

            const messagesInvolvingCurrentUser = messages.filter(message => message.senderId === getCurrentUserId() || message.receiverId === getCurrentUserId())

            messagesInvolvingCurrentUser.forEach(async message => {
                const users = [
                    ...(await (await fetch('http://localhost:3000/api/get-job-seekers')).json()),
                    ...(await (await fetch('http://localhost:3000/api/get-employers')).json())
                ]

                const isSentByUser = message.senderId === getCurrentUserId()

                const senderName = users.find(user => user._id === message.senderId).name
                const senderUsername = users.find(user => user._id === message.senderId).username
                const receiverName = users.find(user => user._id === message.receiverId).name
                const receiverUsername = users.find(user => user._id === message.receiverId).username

                console.log({
                    senderName,
                    senderUsername,
                    receiverName,
                    receiverUsername
                })

                const messageWrapper = $(`<div class="mt-4 px-6 py-4 border border-gray-300 rounded-md">`)

                messageWrapper.append(
                    $(`<p class="text-sm">${(new Date(message.createdAt)).toLocaleString()}</p>`),
                    $(`<p class="font-medium">${isSentByUser ? `To ${receiverName} (${receiverUsername})` : `By ${senderName} (${senderUsername})`}</p>`),
                    $(`<p class="mt-4">${message.text}</p>`)
                )

                //     $(`<button class="${message.isRead ? 'hidden' : ''} mt-4 py-1 px-4 border bg-gray-200 leading-none rounded-full" @click="
                //         await fetch('http://localhost:3000/api/update-message-is-read-boolean', {
                //             method: 'PUT',
                //             headers: {
                //                 'Content-Type': 'application/json'
                //             },
                //             body: JSON.stringify({
                //                 messageId: '${message._id}',
                //                 isRead: true
                //             })
                //         })

                //         getMessagesButton.click()
                //     ">Mark as read</button>`)
                // )

                $('#messages-wrapper').append(messageWrapper)
            })
        })
})
