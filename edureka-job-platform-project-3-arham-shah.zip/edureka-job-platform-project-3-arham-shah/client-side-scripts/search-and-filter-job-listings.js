function isRegexpValid(regexpString) {
    if (typeof regexpString !== 'string') {
        return false
    }

    try {
        RegExp(regexpString)
        return true
    } catch {
        return false
    }
}

function doesSearchMatchInText(searchString, text, options = { matchCase: false, useRegex: false }) {
    const { matchCase, useRegex } = options

    const preparedText = matchCase ? text : text.toLowerCase()
    const preparedSearchString = matchCase ? searchString : searchString.toLowerCase()

    if (useRegex) {
       return RegExp(searchString, !matchCase ? 'i' : '').test(text)
    }

    return preparedText.includes(preparedSearchString)
}

document.querySelector('#search-job-listings-input').addEventListener('input', ev => {
    if (ev.target.value.trim() === '') {
        $('[data-job-listing]').show()
    }
})

document.querySelector('#search-job-listings-button').addEventListener('click', ev => {
    const jobListingCards = [...document.querySelectorAll('[data-job-listing]')]

    const searchInput = document.querySelector('#search-job-listings-input')
    const matchCaseCheckbox = document.querySelector('#match-case-checkbox')
    const useRegexCheckbox = document.querySelector('#use-regex-checkbox')

    const matchCase = matchCaseCheckbox.checked
    const useRegex = useRegexCheckbox.checked

    if (useRegex && !isRegexpValid(searchInput.value)) {
        popUp(`Invalid regular expression<br><code>${searchInput.value}</code>`)
    } else {
        jobListingCards.forEach(async jobListingCard => {
            const jobListingButtonsWrapper = jobListingCard.querySelector('[data-job-listing-button-wrapper]')
            const applications = await (await fetch('http://localhost:3000/api/get-applications')).json()

            const jobListingText = [...jobListingCard.children]
                .filter(element => !(
                    element.matches('[data-job-listing-button-wrapper]') ||
                    element.matches('[data-application-status]')
                ))
                .map(element => element.innerText)
                .join('\n')
            ;

            let doesSearchMatch = doesSearchMatchInText(searchInput.value, jobListingText, { matchCase, useRegex })
            let doesFilterMatch

            if (localStorage.currentUser == 'null') {
                $(jobListingCard).hide()

                if (doesSearchMatch) {
                    $(jobListingCard).show()
                }
            } else if (localStorage.currentUser != 'null' && JSON.parse(localStorage.currentUser).role === 'Employer') {
                const filteringOption = document.querySelector('input[type="radio"][name="job-listings-filter-for-employers"]:checked').value
                const applicationsForCurrentJobListing = applications.filter(application => application.jobListing === jobListingCard.dataset.id)
                const isOwnJobListing = !jobListingButtonsWrapper.hidden

                switch (filteringOption) {
                    case 'all': 
                        doesFilterMatch = true
                        break

                    case 'created-by-you':
                        doesFilterMatch = isOwnJobListing
                        break

                    case 'not-created-by-you':
                        doesFilterMatch = !isOwnJobListing
                        break

                    case 'has-applications-pending-to-accept-or-reject':
                        doesFilterMatch = isOwnJobListing && applicationsForCurrentJobListing.length !== 0 && applicationsForCurrentJobListing.some(application => application.status === 'pending')
                        break

                    case 'all-applications-pending-to-accept-or-reject':
                        doesFilterMatch = isOwnJobListing && applicationsForCurrentJobListing.length !== 0 && applicationsForCurrentJobListing.every(application => application.status === 'pending')
                        break

                    case 'no-application-pending-to-accept-or-reject':
                        doesFilterMatch = isOwnJobListing && applicationsForCurrentJobListing.length !== 0 && applicationsForCurrentJobListing.every(application => application.status !== 'pending')
                        break

                    case 'has-received-no-applications':
                        doesFilterMatch = isOwnJobListing && applicationsForCurrentJobListing.length === 0
                        break

                    default:
                        break
                }

                $(jobListingCard).hide()

                if (doesSearchMatch && doesFilterMatch) {
                    $(jobListingCard).show()
                }
            } else if (localStorage.currentUser != 'null' && JSON.parse(localStorage.currentUser).role === 'Job Seeker') {
                const filteringOption = document.querySelector('input[type="radio"][name="job-listings-filter-for-job-seekers"]:checked').value
                jobListingButtonsWrapper.innerText.includes('View Application')

            const jobListingApplicationStatus = jobListingCard.querySelector('[data-application-status]')
                switch (filteringOption) {
                    case 'all': 
                        doesFilterMatch  = true
                        break

                    case 'applied-for':
                        doesFilterMatch = jobListingButtonsWrapper.innerText.includes('View Application')
                        break

                    case 'not-applied-for': {
                        doesFilterMatch = !jobListingButtonsWrapper.innerText.includes('View Application')
                        break
                    }

                    case 'pending': {
                        doesFilterMatch = jobListingApplicationStatus.innerText.trim() === 'Pending'
                        break
                    }

                    case 'not-pending': {
                        doesFilterMatch = obListingApplicationStatus.innerText.trim() !== 'Pending'
                        break
                    }

                    case 'accepted': {
                        doesFilterMatch = jobListingApplicationStatus.innerText.trim() === 'Accepted'
                        break
                    }

                    case 'rejected':
                        doesFilterMatch = jobListingApplicationStatus.innerText.trim() === 'Rejected'
                        break
                }

                $(jobListingCard).hide()

                if (doesSearchMatch && doesFilterMatch) {
                    $(jobListingCard).show()
                }
            }
        })
    }
})

document.querySelector('#filter-job-listings-fieldset-for-job-seekers').addEventListener('input', () => {
    document.querySelector('#search-job-listings-button').click()
})

document.querySelector('#filter-job-listings-fieldset-for-employers').addEventListener('input', () => {
    document.querySelector('#search-job-listings-button').click()
})
